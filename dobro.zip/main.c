/******************************************************************************

1) Crie um programa que receba um número inteiro e exiba o dobro desse número.


*******************************************************************************/
#include <stdio.h>

int main(){

    int numero;
    int dobro;
    
    scanf("%d", &numero);
    
    dobro = numero * 2;
    
    printf("dobro: %d", dobro);

    return 0;
}