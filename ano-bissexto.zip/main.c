/******************************************************************************

3) Crie um programa para determinar se um ano é bissexto. Um ano é bissexto se for divisível por 4 e não for divisível por 100 ou for divisível por 400

*******************************************************************************/
#include <stdio.h>

int main()
{
    int Ano;
    
    printf("Digite Um Ano: ");
    scanf("%d", &Ano);
    
    
    if((Ano % 4 == 0 && Ano % 100 != 0) || (Ano % 400 == 0))
    {
        printf("%d é Ano bissexto.\n", Ano);
        
    }
    else
    {
        printf("%d não é um ano bissexto.\n", Ano);
    }
    
    
    
    
    
    
    
    
    return 0;
}
    
