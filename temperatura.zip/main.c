/******************************************************************************

2) Crie um programa para converter a temperatura de Celsius para Fahrenheit.
Fahrenheit = (Celsius * 1,8) + 32

*******************************************************************************/
#include <stdio.h>

int main()
{
   float Celsius;
   float Fahrenheit;
   
   printf("temperatura em Celsius: ");
   scanf("%f", &Celsius);
   
 Fahrenheit = (Celsius * 1,8) + 32;
 
 printf("%2.f", Fahrenheit);
    
}